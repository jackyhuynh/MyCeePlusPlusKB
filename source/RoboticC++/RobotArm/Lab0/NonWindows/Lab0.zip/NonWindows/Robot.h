
#include <iostream>
#include <queue>
#include <string>

using namespace std;

#define ROBOT_SDK_DEFINES(name) enum name {ZERO = 0x00,OFF = 0x01,ON = 0x02,LOW = 0x04,HIGH = 0x08,x90 = 0x10,x180 = 0x20,x270 = 0x40,x360 = 0x80,EXEC = 0xFF};

#define ROBOT_SDK_CONTAINER(name,container,type) class name : container<type> { public: type get() { type t = front(); pop(); return t; } void set( type t ) { push(t); } bool empty() { return container::empty(); } };

#define ROBOT_SDK_AUTO(name,type) class name { bool b; public: name(bool f=false) : b(f) { cout<<"Robot starting..."<< endl; } void execute(Container& c) { type t=0; while(!c.empty()){ type tt=c.get(); if(tt==EXEC) { action(t); t=0; } else { t += tt; if (b) { string s = bits(t); string ss = bits(tt); cout << "command " << s << "\topcode " << ss << endl; }}}} ~Robot() { cout << "Robot stopped...." << endl; } void action(type t){ if ( t & OFF ) { cout << "Executing off" << endl; return; } switch (t) { case ON+LOW+x90:cout << "Executing low speed 90" << endl; break; case ON+HIGH+x90:cout << "Executing high speed 90" << endl; break;case ON+LOW+x180:cout << "Executing low speed 180" << endl; break;case ON+HIGH+x180:cout << "Executing high speed 180" << endl; break;case ON+LOW+x270:cout << "Executing low speed 270" << endl; break;case ON+HIGH+x270:cout << "Executing high speed 270" << endl; break;case ON+LOW+x360:cout << "Executing low speed 360" << endl; break;case ON+HIGH+x360:cout << "Executing high speed 360" << endl; break;default:cout << "Invalid command " << (int)t << endl; }} string bits(unsigned char cmd){string s = "00000000";int i = 0x01;for (int x=0; x<0x08; x++){ if ( i & cmd )s[0x07-x] = 0x31;i <<= 0x01;}return s;} };

