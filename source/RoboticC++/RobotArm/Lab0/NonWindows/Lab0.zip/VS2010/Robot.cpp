// Robot.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "RobotDLL.h"

void StartRobot()
{
	Robot robot(true);
}

void main()
{
	StartRobot();
}