========================================================================
    LAB0 APPLICATION : Robot Project Overview
========================================================================

This file contains a summary of what you will find in each of the files that
make up your Robot application.

Robot.cpp
    This is the testing C++ console app for the Robot

Robot.h
    Contains the necessary macros for the for the Robot

/////////////////////////////////////////////////////////////////////////////
Other notes:

These files are to be used on non-Windows C++ compilers.  The
code is supplied 'as-is', meaning if it doesn't work or compile, the
author is not responsible for fixing the problems found.  Every
effort has been made to use standard portable C++ code.

The author does not have a non-Windows C++ compiler, so 
cannot be expected to make it work on non-Windows operating
systems or compilers.

/////////////////////////////////////////////////////////////////////////////
